import { showMoviesData } from "./scripts/view/movies.js";

function App() {
    showMoviesData();
}
App();