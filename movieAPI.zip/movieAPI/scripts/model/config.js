export const config = {
    api_key: "8b853ea22b2da094a00861a8d60da1e6",
    popular_movie_url: "discover/movie?sort_by=popularity.desc&api_key=",
    base_url: "https://api.themoviedb.org/3/",
    img_url: "https://image.tmdb.org/t/p/w500",
}